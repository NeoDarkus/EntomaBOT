const Nobu = require('./main/client.js');
new Nobu();